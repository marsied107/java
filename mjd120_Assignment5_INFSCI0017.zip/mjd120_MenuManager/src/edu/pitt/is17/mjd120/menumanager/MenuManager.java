package edu.pitt.is17.mjd120.menumanager;

/**
 *Problem 1: Unit Converter
 *
 *@author Marielle Davis 
 */


public class MenuManager {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
